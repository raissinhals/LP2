using System.Windows.Forms;

namespace Atividade8_LP2
{
    partial class Exercicio4Form
    {
        private System.ComponentModel.IContainer components = null;
        private ListBox listBox1;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.listBox1 = new ListBox();
            this.SuspendLayout();
            this.listBox1.Location = new System.Drawing.Point(20, 20);
            this.listBox1.Size = new System.Drawing.Size(350, 250);
            this.ClientSize = new System.Drawing.Size(400, 300);
            this.Controls.Add(this.listBox1);
            this.Text = "Exercício 4 - Nomes e Tamanhos";
            this.Load += new System.EventHandler(this.Exercicio4Form_Load);
            this.ResumeLayout(false);
        }
    }
}