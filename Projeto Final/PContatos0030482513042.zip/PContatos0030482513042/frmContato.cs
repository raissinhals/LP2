﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PContatos0030482513042
{
    public partial class frmContato : Form
    {
        private DataSet dsContato = new DataSet();
        private bool bInclusao = false;

        public frmContato()
        {
            InitializeComponent();
            this.Load += frmContato_Load;
        }

        private void frmContato_Load(object sender, EventArgs e)
        {

            Cidade cidade = new Cidade();
            DataTable dtCidade = cidade.Listar();

            if (dtCidade.Rows.Count == 0)
            {
                MessageBox.Show("Nenhuma cidade cadastrada no banco.");
            }

            cbxCidadeContato.DisplayMember = "NOME_CIDADE";
            cbxCidadeContato.ValueMember = "ID_CIDADE";
            cbxCidadeContato.DataSource = dtCidade;
            cbxCidadeContato.SelectedIndex = -1;
            cbxCidadeContato.DropDownStyle = ComboBoxStyle.DropDownList;
        }


        private void btnNovo_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
                tbContato.SelectTab(1);

            if (bnContato.BindingSource != null)
                ((BindingSource)bnContato.BindingSource).AddNew();

            txtNomeContato.Enabled = true;
            txtEndContato.Enabled = true;
            cbxCidadeContato.Enabled = true;

            if (cbxCidadeContato.Items.Count > 0)
                cbxCidadeContato.SelectedIndex = 0;
            else
                cbxCidadeContato.SelectedIndex = -1;

            txtCelContato.Enabled = true;
            txtEmailContato.Enabled = true;
            dtpDtCadastroContato.Enabled = true;

            btnNovo.Enabled = true;
            btnAlterar.Enabled = false;
            btnExcluir.Enabled = false;
            btnSalvar.Enabled = true;
            btnCancelar.Enabled = true;

            bInclusao = true;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (txtNomeContato.Text == "")
            {
                MessageBox.Show("Nome inválido!");
                return;
            }
            if (txtEndContato.Text == "")
            {
                MessageBox.Show("Endereço inválido!");
                return;
            }
            if (cbxCidadeContato.SelectedIndex == -1)
            {
                MessageBox.Show("Cidade inválida!");
                return;
            }
            if (txtCelContato.Text == "")
            {
                MessageBox.Show("Celular inválido!");
                return;
            }
            if (txtEmailContato.Text == "")
            {
                MessageBox.Show("E-mail inválido!");
                return;
            }

            Contato RegCon = new Contato();

            RegCon.Nomecontato = txtNomeContato.Text;
            RegCon.Endcontato = txtEndContato.Text;
            RegCon.Cidadeidcidade = Convert.ToInt32(cbxCidadeContato.SelectedValue);
            RegCon.Celcontato = txtCelContato.Text;
            RegCon.Emailcontato = txtEmailContato.Text;
            RegCon.Dtcadastrocontato = dtpDtCadastroContato.Value;

            if (bInclusao)
            {
                if (RegCon.Incluir() > 0)
                {
                    MessageBox.Show("Contato adicionado com sucesso!");

                    desabilitaCampos();
                    habilitaBotoesPadrao();

                    bInclusao = false;

                    recarregarGrid();
                }
                else
                {
                    MessageBox.Show("Erro ao gravar contato!");
                }
            }
            else
            {
                RegCon.Idcontato = Convert.ToInt32(txtIdContato.Text);

                if (RegCon.Alterar() > 0)
                {
                    MessageBox.Show("Contato alterado com sucesso!");

                    desabilitaCampos();
                    habilitaBotoesPadrao();
                    recarregarGrid();
                }
                else
                {
                    MessageBox.Show("Erro ao alterar contato!");
                }
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
                tbContato.SelectTab(1);

            habilitaCampos();

            btnNovo.Enabled = false;
            btnAlterar.Enabled = false;
            btnExcluir.Enabled = false;
            btnSalvar.Enabled = true;
            btnCancelar.Enabled = true;

            bInclusao = false;
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
                tbContato.SelectTab(1);

            if (MessageBox.Show("Confirma exclusão?", "Excluir",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                == DialogResult.Yes)
            {
                Contato RegCon = new Contato();
                RegCon.Idcontato = Convert.ToInt32(txtIdContato.Text);

                if (RegCon.Excluir() > 0)
                {
                    MessageBox.Show("Contato excluído com sucesso!");
                    recarregarGrid();
                }
                else
                {
                    MessageBox.Show("Erro ao excluir contato!");
                }
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            if (bnContato.BindingSource != null)
                ((BindingSource)bnContato.BindingSource).CancelEdit();


            desabilitaCampos();
            habilitaBotoesPadrao();

            bInclusao = false;
        }

        private void desabilitaCampos()
        {
            txtNomeContato.Enabled = false;
            txtEndContato.Enabled = false;
            cbxCidadeContato.Enabled = false;
            txtCelContato.Enabled = false;
            txtEmailContato.Enabled = false;
            dtpDtCadastroContato.Enabled = false;
        }

        private void habilitaCampos()
        {
            txtNomeContato.Enabled = true;
            txtEndContato.Enabled = true;
            cbxCidadeContato.Enabled = true;
            txtCelContato.Enabled = true;
            txtEmailContato.Enabled = true;
            dtpDtCadastroContato.Enabled = true;
        }

        private void habilitaBotoesPadrao()
        {
            btnNovo.Enabled = true;
            btnAlterar.Enabled = true;
            btnExcluir.Enabled = true;
            btnSalvar.Enabled = false;
            btnCancelar.Enabled = false;
        }

        private void recarregarGrid()
        {
            Contato RegCon = new Contato();
            dsContato.Tables.Clear();
            dsContato.Tables.Add(RegCon.Listar());
            dsContato.Tables[0].TableName = "Contato";

            bnContato.BindingSource = new BindingSource(dsContato, "Contato");
            dgvContatos.DataSource = bnContato.BindingSource;
        }

        private void dgvContatos_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvContatos.CurrentRow == null) return;

            txtIdContato.Text = dgvContatos.CurrentRow.Cells["ID_CONTATO"].Value.ToString();
            txtNomeContato.Text = dgvContatos.CurrentRow.Cells["NOME_CONTATO"].Value.ToString();
            txtEndContato.Text = dgvContatos.CurrentRow.Cells["END_CONTATO"].Value.ToString();
            cbxCidadeContato.SelectedValue = dgvContatos.CurrentRow.Cells["CIDADE_ID_CIDADE"].Value;
            txtCelContato.Text = dgvContatos.CurrentRow.Cells["CEL_CONTATO"].Value.ToString();
            txtEmailContato.Text = dgvContatos.CurrentRow.Cells["EMAIL_CONTATO"].Value.ToString();
            dtpDtCadastroContato.Value = Convert.ToDateTime(dgvContatos.CurrentRow.Cells["DTCADASTRO_CONTATO"].Value);
        }

        private void dgvContatos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

