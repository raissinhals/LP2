﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PContatos0030482513042
{

    public partial class frmPrincipal : Form
    {
        public static SqlConnection CONEXAO;

        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                string cs = ConfigurationManager.ConnectionStrings["LP2"].ConnectionString;

                CONEXAO = new SqlConnection(cs);
                CONEXAO.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao conectar no banco:\n" + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void frmPrincipal_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (CONEXAO != null && CONEXAO.State == System.Data.ConnectionState.Open)
                {
                    CONEXAO.Close();
                }
            }
            catch { }
        }

        private void menuContatos_Click(object sender, EventArgs e)
        {
            frmContato f = new frmContato();
            f.MdiParent = this;
            f.Show();
        }

        private void menuSobre_Click(object sender, EventArgs e)
        {
            frmSobre f = new frmSobre();
            f.ShowDialog();
        }


        private void menuSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
