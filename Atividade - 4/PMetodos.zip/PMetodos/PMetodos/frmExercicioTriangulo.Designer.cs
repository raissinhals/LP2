namespace PMetodos
{
    partial class frmExercicioTriangulo
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.TextBox txtB;
        private System.Windows.Forms.TextBox txtC;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.Label lblResultado;

        private void InitializeComponent()
        {
            this.txtA = new System.Windows.Forms.TextBox();
            this.txtB = new System.Windows.Forms.TextBox();
            this.txtC = new System.Windows.Forms.TextBox();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            this.txtA.Location = new System.Drawing.Point(60, 40);
            this.txtB.Location = new System.Drawing.Point(60, 80);
            this.txtC.Location = new System.Drawing.Point(60, 120);
            this.btnVerificar.Text = "Verificar";
            this.btnVerificar.Location = new System.Drawing.Point(60, 160);
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            this.lblResultado.Location = new System.Drawing.Point(60, 210);
            this.Controls.AddRange(new System.Windows.Forms.Control[] { this.txtA, this.txtB, this.txtC, this.btnVerificar, this.lblResultado });
            this.Text = "Exercício Triângulo";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
