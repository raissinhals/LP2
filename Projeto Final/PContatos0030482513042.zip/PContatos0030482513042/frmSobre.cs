﻿using System;
using System.Windows.Forms;

namespace PContatos0030482513042
{
    public partial class frmSobre : Form
    {
        public frmSobre()
        {
            InitializeComponent();
        }
    }
}
