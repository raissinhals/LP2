namespace PMetodos
{
    partial class frmExercicio2
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox txtPalavra1;
        private System.Windows.Forms.TextBox txtPalavra2;
        private System.Windows.Forms.Button btnComparar;
        private System.Windows.Forms.Button btnInserirNoMeio;
        private System.Windows.Forms.Button btnAsteriscos;

        private void InitializeComponent()
        {
            this.txtPalavra1 = new System.Windows.Forms.TextBox();
            this.txtPalavra2 = new System.Windows.Forms.TextBox();
            this.btnComparar = new System.Windows.Forms.Button();
            this.btnInserirNoMeio = new System.Windows.Forms.Button();
            this.btnAsteriscos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            this.txtPalavra1.Location = new System.Drawing.Point(50, 40);
            this.txtPalavra2.Location = new System.Drawing.Point(50, 80);
            this.btnComparar.Text = "Comparar";
            this.btnComparar.Location = new System.Drawing.Point(50, 120);
            this.btnComparar.Click += new System.EventHandler(this.btnComparar_Click);
            this.btnInserirNoMeio.Text = "Inserir Texto 1 no Meio do Texto 2";
            this.btnInserirNoMeio.Location = new System.Drawing.Point(160, 120);
            this.btnInserirNoMeio.Click += new System.EventHandler(this.btnInserirNoMeio_Click);
            this.btnAsteriscos.Text = "Inserir ** no Meio do Texto 1";
            this.btnAsteriscos.Location = new System.Drawing.Point(50, 160);
            this.btnAsteriscos.Click += new System.EventHandler(this.btnAsteriscos_Click);
            this.Controls.AddRange(new System.Windows.Forms.Control[] { this.txtPalavra1, this.txtPalavra2, this.btnComparar, this.btnInserirNoMeio, this.btnAsteriscos });
            this.Text = "Exercício 2";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
