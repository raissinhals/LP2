using System;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2() { InitializeComponent(); }

        private void btnComparar_Click(object sender, EventArgs e)
        {
            int resultado = String.Compare(txtPalavra1.Text, txtPalavra2.Text);
            MessageBox.Show(resultado == 0 ? "Os textos são iguais." : "Os textos são diferentes.");
        }

        private void btnInserirNoMeio_Click(object sender, EventArgs e)
        {
            string p1 = txtPalavra1.Text;
            string p2 = txtPalavra2.Text;
            int meio = p2.Length / 2;
            txtPalavra2.Text = p2.Substring(0, meio) + p1 + p2.Substring(meio);
        }

        private void btnAsteriscos_Click(object sender, EventArgs e)
        {
            string p1 = txtPalavra1.Text;
            int meio = p1.Length / 2;
            txtPalavra2.Text = p1.Insert(meio, "**");
        }
    }
}
