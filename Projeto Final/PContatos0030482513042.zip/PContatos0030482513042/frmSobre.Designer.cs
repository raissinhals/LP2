﻿namespace PContatos0030482513042
{
    partial class frmSobre
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.PictureBox pictureSobre;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSobre));
            this.pictureSobre = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureSobre)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureSobre
            // 
            this.pictureSobre.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureSobre.BackgroundImage")));
            this.pictureSobre.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureSobre.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureSobre.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureSobre.Location = new System.Drawing.Point(0, 0);
            this.pictureSobre.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureSobre.Name = "pictureSobre";
            this.pictureSobre.Size = new System.Drawing.Size(1622, 879);
            this.pictureSobre.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureSobre.TabIndex = 0;
            this.pictureSobre.TabStop = false;
            // 
            // frmSobre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1622, 879);
            this.Controls.Add(this.pictureSobre);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSobre";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sobre";
            ((System.ComponentModel.ISupportInitialize)(this.pictureSobre)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
    }
}
