﻿namespace volume
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtRaio = new TextBox();
            txtVolume = new TextBox();
            txtAltura = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            SuspendLayout();
            // 
            // txtRaio
            // 
            txtRaio.Location = new Point(235, 95);
            txtRaio.Name = "txtRaio";
            txtRaio.Size = new Size(258, 31);
            txtRaio.TabIndex = 0;
            txtRaio.Validated += txtRaio_Validated;
            // 
            // txtVolume
            // 
            txtVolume.Location = new Point(235, 209);
            txtVolume.Name = "txtVolume";
            txtVolume.ReadOnly = true;
            txtVolume.Size = new Size(258, 31);
            txtVolume.TabIndex = 1;
            // 
            // txtAltura
            // 
            txtAltura.Location = new Point(235, 151);
            txtAltura.Name = "txtAltura";
            txtAltura.Size = new Size(258, 31);
            txtAltura.TabIndex = 2;
            txtAltura.Validated += txtAltura_Validated;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(131, 95);
            label1.Name = "label1";
            label1.Size = new Size(47, 25);
            label1.TabIndex = 3;
            label1.Text = "Raio";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(131, 151);
            label2.Name = "label2";
            label2.Size = new Size(59, 25);
            label2.TabIndex = 4;
            label2.Text = "Altura";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(131, 212);
            label3.Name = "label3";
            label3.Size = new Size(72, 25);
            label3.TabIndex = 5;
            label3.Text = "Volume";
            // 
            // button1
            // 
            button1.Location = new Point(160, 287);
            button1.Name = "button1";
            button1.Size = new Size(112, 34);
            button1.TabIndex = 6;
            button1.Text = "Calcular";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(323, 287);
            button2.Name = "button2";
            button2.Size = new Size(112, 34);
            button2.TabIndex = 7;
            button2.Text = "Limpar";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(472, 287);
            button3.Name = "button3";
            button3.Size = new Size(112, 34);
            button3.TabIndex = 8;
            button3.Text = "Fechar";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtAltura);
            Controls.Add(txtVolume);
            Controls.Add(txtRaio);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtRaio;
        private TextBox txtVolume;
        private TextBox txtAltura;
        private Label label1;
        private Label label2;
        private Label label3;
        private Button button1;
        private Button button2;
        private Button button3;
    }
}
