﻿
using System;
using System.Windows.Forms;

namespace PContatos0030482513042
{
    partial class frmContato
    {
        private System.ComponentModel.IContainer components = null;

        // Controles principais
        private System.Windows.Forms.TabControl tbContato;
        private System.Windows.Forms.TabPage tabLista;
        private System.Windows.Forms.TabPage tabCadastro;
        private System.Windows.Forms.DataGridView dgvContatos;
        private System.Windows.Forms.BindingNavigator bnContato;
        private System.Windows.Forms.BindingSource bsContato;

        // ToolStrip buttons (no BindingNavigator)
        private System.Windows.Forms.ToolStripButton btnNovo;
        private System.Windows.Forms.ToolStripButton btnAlterar;
        private System.Windows.Forms.ToolStripButton btnExcluir;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton btnSalvar;
        private System.Windows.Forms.ToolStripButton btnCancelar;

        // Campos do cadastro
        private System.Windows.Forms.TextBox txtIdContato;
        private System.Windows.Forms.TextBox txtNomeContato;
        private System.Windows.Forms.TextBox txtEndContato;
        private System.Windows.Forms.ComboBox cbxCidadeContato;
        private System.Windows.Forms.TextBox txtCelContato;
        private System.Windows.Forms.TextBox txtEmailContato;
        private System.Windows.Forms.DateTimePicker dtpDtCadastroContato;

        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblEnd;
        private System.Windows.Forms.Label lblCidade;
        private System.Windows.Forms.Label lblCel;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblDt;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmContato));
            this.tbContato = new System.Windows.Forms.TabControl();
            this.tabLista = new System.Windows.Forms.TabPage();
            this.bnContato = new System.Windows.Forms.BindingNavigator(this.components);
            this.bsContato = new System.Windows.Forms.BindingSource(this.components);
            this.btnNovo = new System.Windows.Forms.ToolStripButton();
            this.btnAlterar = new System.Windows.Forms.ToolStripButton();
            this.btnExcluir = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btnSalvar = new System.Windows.Forms.ToolStripButton();
            this.btnCancelar = new System.Windows.Forms.ToolStripButton();
            this.dgvContatos = new System.Windows.Forms.DataGridView();
            this.tabCadastro = new System.Windows.Forms.TabPage();
            this.lblId = new System.Windows.Forms.Label();
            this.txtIdContato = new System.Windows.Forms.TextBox();
            this.lblNome = new System.Windows.Forms.Label();
            this.txtNomeContato = new System.Windows.Forms.TextBox();
            this.lblEnd = new System.Windows.Forms.Label();
            this.txtEndContato = new System.Windows.Forms.TextBox();
            this.lblCidade = new System.Windows.Forms.Label();
            this.cbxCidadeContato = new System.Windows.Forms.ComboBox();
            this.lblCel = new System.Windows.Forms.Label();
            this.txtCelContato = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtEmailContato = new System.Windows.Forms.TextBox();
            this.lblDt = new System.Windows.Forms.Label();
            this.dtpDtCadastroContato = new System.Windows.Forms.DateTimePicker();
            this.tbContato.SuspendLayout();
            this.tabLista.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bnContato)).BeginInit();
            this.bnContato.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsContato)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContatos)).BeginInit();
            this.tabCadastro.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbContato
            // 
            this.tbContato.Controls.Add(this.tabLista);
            this.tbContato.Controls.Add(this.tabCadastro);
            this.tbContato.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbContato.Location = new System.Drawing.Point(0, 0);
            this.tbContato.Name = "tbContato";
            this.tbContato.SelectedIndex = 0;
            this.tbContato.Size = new System.Drawing.Size(766, 424);
            this.tbContato.TabIndex = 0;
            // 
            // tabLista
            // 
            this.tabLista.Controls.Add(this.bnContato);
            this.tabLista.Controls.Add(this.dgvContatos);
            this.tabLista.Location = new System.Drawing.Point(4, 29);
            this.tabLista.Name = "tabLista";
            this.tabLista.Padding = new System.Windows.Forms.Padding(3);
            this.tabLista.Size = new System.Drawing.Size(758, 391);
            this.tabLista.TabIndex = 0;
            this.tabLista.Text = "Lista";
            this.tabLista.UseVisualStyleBackColor = true;
            // 
            // bnContato
            // 
            this.bnContato.AddNewItem = null;
            this.bnContato.BindingSource = this.bsContato;
            this.bnContato.CountItem = null;
            this.bnContato.DeleteItem = null;
            this.bnContato.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.bnContato.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNovo,
            this.btnAlterar,
            this.btnExcluir,
            this.toolStripSeparator1,
            this.btnSalvar,
            this.btnCancelar});
            this.bnContato.Location = new System.Drawing.Point(3, 3);
            this.bnContato.MoveFirstItem = null;
            this.bnContato.MoveLastItem = null;
            this.bnContato.MoveNextItem = null;
            this.bnContato.MovePreviousItem = null;
            this.bnContato.Name = "bnContato";
            this.bnContato.PositionItem = null;
            this.bnContato.Size = new System.Drawing.Size(752, 33);
            this.bnContato.TabIndex = 0;
            this.bnContato.Text = "bindingNavigator1";
            // 
            // btnNovo
            // 
            this.btnNovo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnNovo.BackgroundImage")));
            this.btnNovo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnNovo.Image = ((System.Drawing.Image)(resources.GetObject("btnNovo.Image")));
            this.btnNovo.Name = "btnNovo";
            this.btnNovo.Size = new System.Drawing.Size(34, 28);
            this.btnNovo.Text = "Novo";
            this.btnNovo.Click += new System.EventHandler(this.btnNovo_Click);
            // 
            // btnAlterar
            // 
            this.btnAlterar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnAlterar.Image = ((System.Drawing.Image)(resources.GetObject("btnAlterar.Image")));
            this.btnAlterar.Name = "btnAlterar";
            this.btnAlterar.Size = new System.Drawing.Size(34, 28);
            this.btnAlterar.Text = "Alterar";
            this.btnAlterar.Click += new System.EventHandler(this.btnAlterar_Click);
            // 
            // btnExcluir
            // 
            this.btnExcluir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnExcluir.Image = ((System.Drawing.Image)(resources.GetObject("btnExcluir.Image")));
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(34, 28);
            this.btnExcluir.Text = "Excluir";
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 33);
            // 
            // btnSalvar
            // 
            this.btnSalvar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSalvar.Enabled = false;
            this.btnSalvar.Image = ((System.Drawing.Image)(resources.GetObject("btnSalvar.Image")));
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(34, 28);
            this.btnSalvar.Text = "Salvar";
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnCancelar.Enabled = false;
            this.btnCancelar.Image = ((System.Drawing.Image)(resources.GetObject("btnCancelar.Image")));
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(34, 28);
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // dgvContatos
            // 
            this.dgvContatos.AllowUserToAddRows = false;
            this.dgvContatos.AllowUserToDeleteRows = false;
            this.dgvContatos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvContatos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvContatos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvContatos.Location = new System.Drawing.Point(3, 3);
            this.dgvContatos.MultiSelect = false;
            this.dgvContatos.Name = "dgvContatos";
            this.dgvContatos.ReadOnly = true;
            this.dgvContatos.RowHeadersWidth = 62;
            this.dgvContatos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvContatos.Size = new System.Drawing.Size(752, 385);
            this.dgvContatos.TabIndex = 1;
            this.dgvContatos.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvContatos_CellContentClick);
            this.dgvContatos.SelectionChanged += new System.EventHandler(this.dgvContatos_SelectionChanged);
            // 
            // tabCadastro
            // 
            this.tabCadastro.Controls.Add(this.lblId);
            this.tabCadastro.Controls.Add(this.txtIdContato);
            this.tabCadastro.Controls.Add(this.lblNome);
            this.tabCadastro.Controls.Add(this.txtNomeContato);
            this.tabCadastro.Controls.Add(this.lblEnd);
            this.tabCadastro.Controls.Add(this.txtEndContato);
            this.tabCadastro.Controls.Add(this.lblCidade);
            this.tabCadastro.Controls.Add(this.cbxCidadeContato);
            this.tabCadastro.Controls.Add(this.lblCel);
            this.tabCadastro.Controls.Add(this.txtCelContato);
            this.tabCadastro.Controls.Add(this.lblEmail);
            this.tabCadastro.Controls.Add(this.txtEmailContato);
            this.tabCadastro.Controls.Add(this.lblDt);
            this.tabCadastro.Controls.Add(this.dtpDtCadastroContato);
            this.tabCadastro.Location = new System.Drawing.Point(4, 29);
            this.tabCadastro.Name = "tabCadastro";
            this.tabCadastro.Padding = new System.Windows.Forms.Padding(3);
            this.tabCadastro.Size = new System.Drawing.Size(688, 331);
            this.tabCadastro.TabIndex = 1;
            this.tabCadastro.Text = "Cadastro";
            this.tabCadastro.UseVisualStyleBackColor = true;
            // 
            // lblId
            // 
            this.lblId.AutoSize = true;
            this.lblId.Location = new System.Drawing.Point(23, 23);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(26, 20);
            this.lblId.TabIndex = 0;
            this.lblId.Text = "ID";
            // 
            // txtIdContato
            // 
            this.txtIdContato.Enabled = false;
            this.txtIdContato.Location = new System.Drawing.Point(120, 17);
            this.txtIdContato.Name = "txtIdContato";
            this.txtIdContato.Size = new System.Drawing.Size(200, 26);
            this.txtIdContato.TabIndex = 1;
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(23, 53);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(51, 20);
            this.lblNome.TabIndex = 2;
            this.lblNome.Text = "Nome";
            // 
            // txtNomeContato
            // 
            this.txtNomeContato.Location = new System.Drawing.Point(120, 47);
            this.txtNomeContato.Name = "txtNomeContato";
            this.txtNomeContato.Size = new System.Drawing.Size(400, 26);
            this.txtNomeContato.TabIndex = 3;
            // 
            // lblEnd
            // 
            this.lblEnd.AutoSize = true;
            this.lblEnd.Location = new System.Drawing.Point(23, 83);
            this.lblEnd.Name = "lblEnd";
            this.lblEnd.Size = new System.Drawing.Size(78, 20);
            this.lblEnd.TabIndex = 4;
            this.lblEnd.Text = "Endereço";
            // 
            // txtEndContato
            // 
            this.txtEndContato.Location = new System.Drawing.Point(120, 77);
            this.txtEndContato.Name = "txtEndContato";
            this.txtEndContato.Size = new System.Drawing.Size(400, 26);
            this.txtEndContato.TabIndex = 5;
            // 
            // lblCidade
            // 
            this.lblCidade.AutoSize = true;
            this.lblCidade.Location = new System.Drawing.Point(23, 113);
            this.lblCidade.Name = "lblCidade";
            this.lblCidade.Size = new System.Drawing.Size(59, 20);
            this.lblCidade.TabIndex = 6;
            this.lblCidade.Text = "Cidade";
            // 
            // cbxCidadeContato
            // 
            this.cbxCidadeContato.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxCidadeContato.Location = new System.Drawing.Point(120, 107);
            this.cbxCidadeContato.Name = "cbxCidadeContato";
            this.cbxCidadeContato.Size = new System.Drawing.Size(200, 28);
            this.cbxCidadeContato.TabIndex = 7;
            // 
            // lblCel
            // 
            this.lblCel.AutoSize = true;
            this.lblCel.Location = new System.Drawing.Point(23, 143);
            this.lblCel.Name = "lblCel";
            this.lblCel.Size = new System.Drawing.Size(58, 20);
            this.lblCel.TabIndex = 8;
            this.lblCel.Text = "Celular";
            // 
            // txtCelContato
            // 
            this.txtCelContato.Location = new System.Drawing.Point(120, 137);
            this.txtCelContato.Name = "txtCelContato";
            this.txtCelContato.Size = new System.Drawing.Size(200, 26);
            this.txtCelContato.TabIndex = 9;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(23, 173);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(53, 20);
            this.lblEmail.TabIndex = 10;
            this.lblEmail.Text = "E-mail";
            // 
            // txtEmailContato
            // 
            this.txtEmailContato.Location = new System.Drawing.Point(120, 167);
            this.txtEmailContato.Name = "txtEmailContato";
            this.txtEmailContato.Size = new System.Drawing.Size(300, 26);
            this.txtEmailContato.TabIndex = 11;
            // 
            // lblDt
            // 
            this.lblDt.AutoSize = true;
            this.lblDt.Location = new System.Drawing.Point(23, 203);
            this.lblDt.Name = "lblDt";
            this.lblDt.Size = new System.Drawing.Size(95, 20);
            this.lblDt.TabIndex = 12;
            this.lblDt.Text = "Dt Cadastro";
            // 
            // dtpDtCadastroContato
            // 
            this.dtpDtCadastroContato.Location = new System.Drawing.Point(120, 197);
            this.dtpDtCadastroContato.Name = "dtpDtCadastroContato";
            this.dtpDtCadastroContato.Size = new System.Drawing.Size(200, 26);
            this.dtpDtCadastroContato.TabIndex = 13;
            // 
            // frmContato
            // 
            this.ClientSize = new System.Drawing.Size(766, 424);
            this.Controls.Add(this.tbContato);
            this.Name = "frmContato";
            this.tbContato.ResumeLayout(false);
            this.tabLista.ResumeLayout(false);
            this.tabLista.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bnContato)).EndInit();
            this.bnContato.ResumeLayout(false);
            this.bnContato.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsContato)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContatos)).EndInit();
            this.tabCadastro.ResumeLayout(false);
            this.tabCadastro.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
    }
}
