using System;
using System.Linq;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void exercicio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["frmExercicio2"] != null)
                Application.OpenForms["frmExercicio2"]?.BringToFront();
            else
            {
                frmExercicio2 objFrm2 = new frmExercicio2();
                objFrm2.MdiParent = this;
                objFrm2.WindowState = FormWindowState.Maximized;
                objFrm2.Show();
            }
        }

        private void trianguloToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["frmExercicioTriangulo"] != null)
                Application.OpenForms["frmExercicioTriangulo"]?.BringToFront();
            else
            {
                frmExercicioTriangulo frm = new frmExercicioTriangulo();
                frm.MdiParent = this;
                frm.WindowState = FormWindowState.Maximized;
                frm.Show();
            }
        }
    }
}
