using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Atividade8_LP2
{
    public partial class Exercicio4Form : Form
    {
        public Exercicio4Form()
        {
            InitializeComponent();
        }

        private void Exercicio4Form_Load(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            int[] tamanhos = new int[10];

            for (int i = 0; i < 10; i++)
            {
                string nome;
                do
                {
                    nome = Interaction.InputBox($"Digite o nome completo da {i + 1}ª pessoa:").Trim();
                } while (string.IsNullOrWhiteSpace(nome));

                nomes[i] = nome;
                tamanhos[i] = nome.Replace(" ", "").Length;
            }

            for (int i = 0; i < 10; i++)
            {
                listBox1.Items.Add($"{nomes[i]} - {tamanhos[i]} caracteres");
            }
        }
    }
}