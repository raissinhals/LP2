namespace volume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double raio, altura, volume;

            if (double.TryParse(txtRaio.Text, out raio) && double.TryParse(txtAltura.Text, out altura))
            {
                volume = Math.PI * Math.Pow(raio, 2) * altura;

                txtVolume.Text = volume.ToString("F2");
            }
            else
            {
                MessageBox.Show("Digite valores num�ricos v�lidos para raio e altura.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtRaio.Text = "";
            txtAltura.Text = "";
            txtVolume.Text = "";

            txtRaio.Focus();
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            double valor;
            if (!double.TryParse(txtRaio.Text, out valor))
            {
                MessageBox.Show("Raio Inv�lido");
                txtRaio.Focus();
            }
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            double valor;
            if (!double.TryParse(txtAltura.Text, out valor))
            {
                MessageBox.Show("Altura Inv�lido");
                txtAltura.Focus();
            }
        }
    }
}
