using System;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicioTriangulo : Form
    {
        public frmExercicioTriangulo() { InitializeComponent(); }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double a = double.Parse(txtA.Text);
            double b = double.Parse(txtB.Text);
            double c = double.Parse(txtC.Text);

            if (a < b + c && b < a + c && c < a + b)
            {
                if (a == b && b == c)
                    lblResultado.Text = "Triângulo Equilátero";
                else if (a == b || a == c || b == c)
                    lblResultado.Text = "Triângulo Isósceles";
                else
                    lblResultado.Text = "Triângulo Escaleno";
            }
            else lblResultado.Text = "Os valores informados não formam um triângulo.";
        }
    }
}
