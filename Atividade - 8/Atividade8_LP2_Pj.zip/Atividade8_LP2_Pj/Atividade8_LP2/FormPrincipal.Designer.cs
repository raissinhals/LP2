using System.Windows.Forms;

namespace Atividade8_LP2
{
    partial class FormPrincipal
    {
        private System.ComponentModel.IContainer components = null;
        private Button btnEx1;
        private Button btnEx2;
        private Button btnEx3;
        private Button btnEx4;
        private Button btnEx5;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.btnEx1 = new Button();
            this.btnEx2 = new Button();
            this.btnEx3 = new Button();
            this.btnEx4 = new Button();
            this.btnEx5 = new Button();
            this.SuspendLayout();

            this.btnEx1.Text = "Exercício 1";
            this.btnEx1.Location = new System.Drawing.Point(50, 30);
            this.btnEx1.Click += new System.EventHandler(this.btnEx1_Click);

            this.btnEx2.Text = "Exercício 2";
            this.btnEx2.Location = new System.Drawing.Point(50, 80);
            this.btnEx2.Click += new System.EventHandler(this.btnEx2_Click);

            this.btnEx3.Text = "Exercício 3";
            this.btnEx3.Location = new System.Drawing.Point(50, 130);
            this.btnEx3.Click += new System.EventHandler(this.btnEx3_Click);

            this.btnEx4.Text = "Exercício 4";
            this.btnEx4.Location = new System.Drawing.Point(50, 180);
            this.btnEx4.Click += new System.EventHandler(this.btnEx4_Click);

            this.btnEx5.Text = "Exercício 5";
            this.btnEx5.Location = new System.Drawing.Point(50, 230);
            this.btnEx5.Click += new System.EventHandler(this.btnEx5_Click);

            this.ClientSize = new System.Drawing.Size(300, 300);
            this.Controls.Add(this.btnEx1);
            this.Controls.Add(this.btnEx2);
            this.Controls.Add(this.btnEx3);
            this.Controls.Add(this.btnEx4);
            this.Controls.Add(this.btnEx5);
            this.Text = "Atividade 8 - LP2";
            this.ResumeLayout(false);
        }
    }
}