using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Atividade8_LP2
{
    public partial class Exercicio5Form : Form
    {
        public Exercicio5Form()
        {
            InitializeComponent();
        }

        private void Exercicio5Form_Load(object sender, EventArgs e)
        {
            int N = 2; 
            string[] gabarito = { "A", "B", "C", "D", "E", "A", "B", "C", "D", "E" };

            for (int i = 0; i < N; i++)
            {
                int acertos = 0;
                for (int j = 0; j < 10; j++)
                {
                    string resposta;
                    do
                    {
                        resposta = Interaction.InputBox($"Aluno {i + 1} - Questão {j + 1}: (A/B/C/D/E)").ToUpper();
                    } while (!"ABCDE".Contains(resposta));

                    if (resposta == gabarito[j]) acertos++;
                }
                listBox1.Items.Add($"Aluno {i + 1}: {acertos} acertos de 10");
            }
        }
    }
}