using System;
using System.Collections;
using System.Linq;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Atividade8_LP2
{
    public partial class FormPrincipal : Form
    {
        public FormPrincipal()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] numeros = new int[20];
            for (int i = 0; i < 20; i++)
                numeros[i] = int.Parse(Interaction.InputBox($"Digite o {i + 1}º número inteiro:"));

            Array.Reverse(numeros);
            MessageBox.Show("Ordem inversa: " + string.Join(", ", numeros));
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList
            {
                "Ana", "André", "Beatriz", "Camila", "João", "Joana", "Otávio", "Marcelo", "Pedro", "Thais"
            };
            alunos.Remove("Otávio");
            MessageBox.Show("Alunos: " + string.Join(", ", alunos.ToArray()));
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string resultado = "";
            for (int i = 0; i < 20; i++)
            {
                double soma = 0;
                for (int j = 0; j < 3; j++)
                {
                    double nota;
                    do
                    {
                        string entrada = Interaction.InputBox($"Aluno {i + 1} - Digite a nota {j + 1} (0 a 10):");
                        double.TryParse(entrada, out nota);
                    } while (nota < 0 || nota > 10);

                    notas[i, j] = nota;
                    soma += nota;
                }
                double media = soma / 3;
                resultado += $"Aluno {i + 1}: média {media:F1}\n";
            }
            MessageBox.Show(resultado, "Médias dos Alunos");
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            new Exercicio4Form().ShowDialog();
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            new Exercicio5Form().ShowDialog();
        }
    }
}