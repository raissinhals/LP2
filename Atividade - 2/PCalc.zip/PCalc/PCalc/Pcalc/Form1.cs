﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {

        double numero1, numero2, resultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtResultado.Text = resultado.ToString();
            
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNum2_Validated(object sender, EventArgs e)
        {

            try
            {
                numero2 = Convert.ToDouble(txtNum2.Text);
                errorProvider2.SetError(txtNum2, "");

            }
            catch{ 
                
                errorProvider2.SetError(txtNum2, "Número 2 inválido");

            }
           
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Text = txtNum2.Text = txtResultado.Text = "";
            numero1 = numero2 = resultado = 0;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            
            if(MessageBox.Show("Deseja Sair do programa?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }

          
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (numero2 != 0)
            {
                resultado = numero1 / numero2;
                txtResultado.Text = resultado.ToString();
                errorProvider2.SetError(txtNum2, "");
            }else
            {
                errorProvider2.SetError(txtNum2, "Não exsite divisão por Zero");
                txtNum2.Focus();
            }
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum1.Text, out numero1))
            {
                errorProvider1.SetError(txtNum1, "Número 1 inválido");
                txtNum1.Focus();
            }
            else
            {
                errorProvider1.SetError(txtNum1, "");
            }
        }
    }
}
