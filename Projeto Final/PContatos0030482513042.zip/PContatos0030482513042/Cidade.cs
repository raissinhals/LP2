﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PContatos0030482513042
{
    public class Cidade
    {
        public int IdCidade { get; set; }
        public string NomeCidade { get; set; }
        public string UfCidade { get; set; }

        public DataTable Listar()
        {
            DataTable dt = new DataTable();
            string sql = "SELECT ID_CIDADE, NOME_CIDADE, UF_CIDADE FROM CIDADE ORDER BY NOME_CIDADE";

            using (SqlCommand cmd = new SqlCommand(sql, frmPrincipal.CONEXAO))
            using (SqlDataAdapter da = new SqlDataAdapter(cmd))
            {
                da.Fill(dt);
            }

            return dt;
        }
    }
}
