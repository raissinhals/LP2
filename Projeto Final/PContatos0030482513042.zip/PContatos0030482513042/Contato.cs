﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PContatos0030482513042
{
    public class Contato
    {
        public int Idcontato { get; set; }
        public string Nomecontato { get; set; }
        public string Endcontato { get; set; }
        public int Cidadeidcidade { get; set; }
        public string Celcontato { get; set; }
        public string Emailcontato { get; set; }
        public DateTime Dtcadastrocontato { get; set; }

        public int Incluir()
        {
            string sql = @"
            INSERT INTO CONTATO (NOME_CONTATO, END_CONTATO, CIDADE_ID_CIDADE, CEL_CONTATO, EMAIL_CONTATO, DTCADASTRO_CONTATO)
            VALUES (@nome, @end, @cidade, @cel, @email, @dt);";

            using (SqlCommand cmd = new SqlCommand(sql, frmPrincipal.CONEXAO))
            {
                cmd.Parameters.AddWithValue("@nome", Nomecontato);
                cmd.Parameters.AddWithValue("@end", Endcontato);
                cmd.Parameters.AddWithValue("@cidade", Cidadeidcidade);
                cmd.Parameters.AddWithValue("@cel", Celcontato);
                cmd.Parameters.AddWithValue("@email", Emailcontato);
                cmd.Parameters.AddWithValue("@dt", Dtcadastrocontato.Date);
                return cmd.ExecuteNonQuery();
            }
        }

        public int Alterar()
        {
            string sql = @"
            UPDATE CONTATO SET
                NOME_CONTATO = @nome,
                END_CONTATO = @end,
                CIDADE_ID_CIDADE = @cidade,
                CEL_CONTATO = @cel,
                EMAIL_CONTATO = @email,
                DTCADASTRO_CONTATO = @dt
            WHERE ID_CONTATO = @id;";

            using (SqlCommand cmd = new SqlCommand(sql, frmPrincipal.CONEXAO))
            {
                cmd.Parameters.AddWithValue("@nome", Nomecontato);
                cmd.Parameters.AddWithValue("@end", Endcontato);
                cmd.Parameters.AddWithValue("@cidade", Cidadeidcidade);
                cmd.Parameters.AddWithValue("@cel", Celcontato);
                cmd.Parameters.AddWithValue("@email", Emailcontato);
                cmd.Parameters.AddWithValue("@dt", Dtcadastrocontato.Date);
                cmd.Parameters.AddWithValue("@id", Idcontato);
                return cmd.ExecuteNonQuery();
            }
        }

        public int Excluir()
        {
            string sql = "DELETE FROM CONTATO WHERE ID_CONTATO = @id";
            using (SqlCommand cmd = new SqlCommand(sql, frmPrincipal.CONEXAO))
            {
                cmd.Parameters.AddWithValue("@id", Idcontato);
                return cmd.ExecuteNonQuery();
            }
        }

        public DataTable Listar()
        {
            DataTable dt = new DataTable();
            string sql = @"SELECT ID_CONTATO, NOME_CONTATO, END_CONTATO, CIDADE_ID_CIDADE, CEL_CONTATO, EMAIL_CONTATO, DTCADASTRO_CONTATO FROM CONTATO";

            using (SqlCommand cmd = new SqlCommand(sql, frmPrincipal.CONEXAO))
            using (SqlDataAdapter da = new SqlDataAdapter(cmd))
            {
                da.Fill(dt);
            }
            return dt;
        }
    }
}
